- Copy x86 dlls to SYSWOW64 or system32 depending on your OS.
- Copy include and lib files to corresponding VS include and lib folders.
- Add assimp.lib to VS linker inputs
- (Optional) Download and install assimp sdk for free models and 3D Viewer
http://sourceforge.net/projects/assimp/files/assimp-3.0/assimp-sdk-3.0-setup.exe/download